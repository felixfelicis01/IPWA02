import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection = null;
		String url = "jdbc:mariadb://localhost:3306/Employees";
		String user = "app";
		String password = "Start2023!";
		
		try
		{
			connection = DriverManager.getConnection(url, user, password);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}		
		System.out.println("Errrfolg");

	}

}
