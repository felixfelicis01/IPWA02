package require4testing.model;

import java.util.List;

public class Benutzer 
{
	long id; // die IDs sollen als einzigartige Werte genutzt werden können und können daher nach längerer Nutzung zu groß für die Nutzung von int sein
	String name;
	String rolle;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRolle() {
		return rolle;
	}
	public void setRolle(String rolle) {
		this.rolle = rolle;
	}
	@Override
	public String toString() {
		return "Benutzer [id=" + id + ", name=" + name + ", rolle=" + rolle + "]";
	}
	
	
}
