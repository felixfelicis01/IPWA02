package require4testing.model;

public class TestfallTestergebnis 
{
	long testergebnisID;
	long anforderungID;	
	long testfallID;
	long testerID;
	String testfallBeschreibung;
	String ergebnisBeschreibung;
	
	public long getTestergebnisID() {
		return testergebnisID;
	}
	public void setTestergebnisID(long testergebnisID) {
		this.testergebnisID = testergebnisID;
	}
	public long getAnforderungID() {
		return anforderungID;
	}
	public void setAnforderungID(long anforderungID) {
		this.anforderungID = anforderungID;
	}
	public long getTestfallID() {
		return testfallID;
	}
	public void setTestfallID(long testfallID) {
		this.testfallID = testfallID;
	}
	public long getTesterID() {
		return testerID;
	}
	public void setTesterID(long testerID) {
		this.testerID = testerID;
	}
	public String getTestfallBeschreibung() {
		return testfallBeschreibung;
	}
	public void setTestfallBeschreibung(String testfallBeschreibung) {
		this.testfallBeschreibung = testfallBeschreibung;
	}
	public String getErgebnisBeschreibung() {
		return ergebnisBeschreibung;
	}
	public void setErgebnisBeschreibung(String ergebnisBeschreibung) {
		this.ergebnisBeschreibung = ergebnisBeschreibung;
	}
	@Override
	public String toString() {
		return "TestfallTestergebnis [testergebnisID=" + testergebnisID + ", anforderungID=" + anforderungID
				+ ", testfallID=" + testfallID + ", testerID=" + testerID + ", testfallBeschreibung="
				+ testfallBeschreibung + ", ergebnisBeschreibung=" + ergebnisBeschreibung + "]";
	}	
	
	
}
