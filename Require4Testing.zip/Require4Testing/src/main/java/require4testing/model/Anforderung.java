package require4testing.model;

import java.util.List;

public class Anforderung 
{
	String beschreibung;
	long id;
	String name;
	
	public String getBeschreibung() {
		return beschreibung;
	}
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Anforderung [beschreibung=" + beschreibung + ", id=" + id + ", name=" + name + "]";
	}
	
	
}
