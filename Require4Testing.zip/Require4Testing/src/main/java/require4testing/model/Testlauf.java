package require4testing.model;

import java.util.ArrayList;

public class Testlauf extends Anforderung
{
	long id;
	long testerId;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}	
	public long getTesterId() {
		return testerId;
	}
	public void setTesterId(long testerId) {
		this.testerId = testerId;
	}
	@Override
	public String toString() {
		return "Testlauf [id=" + id + ", testerId=" + testerId + "]";
	}
	
}
