package require4testing.model;

public class Testergebnis 
{
	long id;
	String beschreibung;
	long testfallID;
	long testerID;
	
	public long getId() 
	{
		return id;
	}
	public void setId(long id) 
	{
		this.id = id;
	}
	public String getBeschreibung() 
	{
		return beschreibung;
	}
	public void setBeschreibung(String beschreibung) 
	{
		this.beschreibung = beschreibung;
	}
	public long getTestfallID() 
	{
		return testfallID;
	}
	public void setTestfallID(long testfallID) 
	{
		this.testfallID = testfallID;
	}
	public long getTesterID() {
		return testerID;
	}
	public void setTesterID(long testerID) {
		this.testerID = testerID;
	}
	@Override
	public String toString() {
		return "Testergebnis [id=" + id + ", beschreibung=" + beschreibung + ", testfallID=" + testfallID
				+ ", testerID=" + testerID + "]";
	}
	
	
	
}
