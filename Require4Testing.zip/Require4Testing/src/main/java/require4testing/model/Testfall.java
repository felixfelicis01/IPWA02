package require4testing.model;

public class Testfall extends Testlauf
{
	long id;
	long anforderungID;
	long testlaufID;
	
	
	public long getId() 
	{
		return id;
	}
	public void setId(long id) 
	{
		this.id = id;
	}	
	
	public long getAnforderungID() {
		return anforderungID;
	}
	public void setAnforderungID(long anforderungID) {
		this.anforderungID = anforderungID;
	}
	public String getBeschreibung() 
	{
		return beschreibung;
	}
	public void setBeschreibung(String beschreibung) 
	{
		this.beschreibung = beschreibung;
	}
	public long getTestlaufID() {
		return testlaufID;
	}
	public void setTestlaufID(long testlaufID) {
		this.testlaufID = testlaufID;
	}
	@Override
	public String toString() {
		return "Testfall [id=" + id + ", anforderungID=" + anforderungID + ", testlaufID=" + testlaufID
				+ ", beschreibung=" + beschreibung + "]";
	}	
}
