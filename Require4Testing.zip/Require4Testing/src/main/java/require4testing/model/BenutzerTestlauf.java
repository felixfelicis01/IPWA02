package require4testing.model;

public class BenutzerTestlauf 
{
	long benutzerId;
	long testlaufId;
	long testfallId;
	String beschreibung;
	String testfallBeschreibung;
	String tester;
	
	public long getBenutzerId() {
		return benutzerId;
	}
	public void setBenutzerId(long benutzerId) {
		this.benutzerId = benutzerId;
	}
	public long getTestlaufId() {
		return testlaufId;
	}
	public void setTestlaufId(long testlaufId) {
		this.testlaufId = testlaufId;
	}	
	public long getTestfallId() {
		return testfallId;
	}
	public void setTestfallId(long testfallId) {
		this.testfallId = testfallId;
	}
	public String getBeschreibung() {
		return beschreibung;
	}
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	public String getTestfallBeschreibung() {
		return testfallBeschreibung;
	}
	public void setTestfallBeschreibung(String testfallBeschreibung) {
		this.testfallBeschreibung = testfallBeschreibung;
	}
	public String getTester() {
		return tester;
	}
	public void setTester(String tester) {
		this.tester = tester;
	}
	@Override
	public String toString() {
		return "BenutzerTestlauf [benutzerId=" + benutzerId + ", testlaufId=" + testlaufId + ", testfallId="
				+ testfallId + ", beschreibung=" + beschreibung + ", testfallBeschreibung=" + testfallBeschreibung
				+ ", tester=" + tester + "]";
	}
	
	
}
