package require4testing.objects;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.mariadb.jdbc.Connection;
import org.mariadb.jdbc.DatabaseMetaData;
import org.mariadb.jdbc.Statement;

import require4testing.model.Anforderung;
import require4testing.model.Benutzer;
import require4testing.model.BenutzerTestlauf;
import require4testing.model.Testergebnis;
import require4testing.model.Testfall;
import require4testing.model.TestfallTestergebnis;
import require4testing.model.Testlauf;

public class DataController 
{
	// TODO Auto-generated method stub
		static final String Driver = "org.mariadb.jdbc.Driver";
		static final String url = "jdbc:mariadb://localhost:3306/Datenbank";
		static final String user = "app";
		static final String password = "Start2023!";			
		
		// Read from Database
		public List<Anforderung> readAnforderungen(){
			List<Anforderung> aList = new ArrayList<Anforderung>();
			Connection conn = null;
			Statement stmt = null;
			String sql;
			String result;
			
			// Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				// System.out.println("Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				// System.out.println("SQL-Statement erstellen...");
				stmt = conn.createStatement();
				
				sql = "SELECT * FROM Datenbank.Anforderung";
				ResultSet rs = stmt.executeQuery(sql);

				// Extract data from result set
				while(rs.next()){
				   Anforderung a = new Anforderung();
				   //Retrieve by column name
				   a.setId(rs.getInt("AnforderungID"));
				   a.setBeschreibung(rs.getString("Beschreibung"));
				   a.setName(rs.getString("Name"));				   
				   aList.add(a);
				}
				// Clean-up environment
				rs.close();				
				stmt.close();
				conn.close();
				return aList;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Lesen in Tabelle Anforderung !");
				return aList;
			} finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long insertAnforderung(Anforderung anforderung){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Verbinden mit Datenbank
				System.out.println("insertAnforderung): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);
				
				sql = "INSERT INTO Datenbank.Anforderung"
						+ "(Name, Beschreibung) VALUES"
						+ "(?,?)";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

				preparedStatement.setString(1, anforderung.getName());
				preparedStatement.setString(2, anforderung.getBeschreibung());

				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		        }

		        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
		            if (generatedKeys.next()) {
		            	idNewRow = generatedKeys.getLong(1);
		            	System.out.println("ID des neuen Objektes: " + idNewRow);
		            }
		            else {
		                throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		            }
		        }			
					
				preparedStatement.close();
				conn.close();
				return idNewRow;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Anlegen der Zeile in Anforderung !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long deleteAnforderung(Anforderung anforderung){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Register JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				System.out.println("deleteAnforderung(): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				sql = "DELETE FROM Datenbank.Anforderung " +
					   "WHERE AnforderungID = ?";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql);

				preparedStatement.setLong(1, anforderung.getId());
				
				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Fehler beim Löschen. Zeile wurde nicht gefunden.");
		        } else {
		        	System.out.println("Objekt gelöscht!");
		        }

		       		
					
				preparedStatement.close();
				conn.close();
				return affectedRows;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Löschen aus Anforderung !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}	
		
		
		
		// Read from Database
		public List<Testlauf> readTestlauf(){
			List<Testlauf> aList = new ArrayList<Testlauf>();
			Connection conn = null;
			Statement stmt = null;
			String sql;
			String result;
			
			// Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				// System.out.println("Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				// System.out.println("SQL-Statement erstellen...");
				stmt = conn.createStatement();
				
				sql = "SELECT * FROM Datenbank.Testlauf";
				ResultSet rs = stmt.executeQuery(sql);

				// Extract data from result set
				while(rs.next()){
				   Testlauf a = new Testlauf();
				   //Retrieve by column name
				   a.setId(rs.getInt("TestlaufID"));
				   a.setBeschreibung(rs.getString("Beschreibung"));

				   
				   //System.out.println(current );
				   aList.add(a);
				}
				// Clean-up environment
				rs.close();
					

				
				stmt.close();
				conn.close();
				return aList;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Lesen in Tabelle Testlauf !");
				return aList;
			} finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long insertTestlauf(Testlauf testlauf){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Verbinden mit Datenbank
				System.out.println("insertTestlauf): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);
				
				sql = "INSERT INTO Datenbank.Testlauf"
						+ "(Beschreibung, TesterID) VALUES"
						+ "(?,?)";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

				preparedStatement.setString(1, testlauf.getBeschreibung());
				preparedStatement.setLong(2, testlauf.getTesterId());

				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		        }

		        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
		            if (generatedKeys.next()) {
		            	idNewRow = generatedKeys.getLong(1);
		            	System.out.println("ID des neuen Objektes: " + idNewRow);
		            }
		            else {
		                throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		            }
		        }			
					
				preparedStatement.close();
				conn.close();
				return idNewRow;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Anlegen der Zeile in Testlauf !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long deleteTestlauf(Testlauf testlauf){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Register JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				System.out.println("deleteTestlauf(): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				sql = "DELETE FROM Datenbank.Testlauf " +
					   "WHERE TestlaufID = ?";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql);

				preparedStatement.setLong(1, testlauf.getId());
				
				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Fehler beim Löschen. Zeile wurde nicht gefunden.");
		        } else {
		        	System.out.println("Objekt gelöscht!");
		        }	       		
					
				preparedStatement.close();
				conn.close();
				return affectedRows;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Löschen aus Testlauf !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		// Read from Database
		public List<Testfall> readTestfall(){
			List<Testfall> aList = new ArrayList<Testfall>();
			Connection conn = null;
			Statement stmt = null;
			String sql;
			String result;
			
			// Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				// System.out.println("Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				// System.out.println("SQL-Statement erstellen...");
				stmt = conn.createStatement();
				
				sql = "SELECT * FROM Datenbank.Testfall";
				ResultSet rs = stmt.executeQuery(sql);

				// Extract data from result set
				while(rs.next()){
				   Testfall a = new Testfall();
				   //Retrieve by column name				   
				   a.setId(rs.getInt("TestfallID"));
				   a.setBeschreibung(rs.getString("Beschreibung"));
				   a.setAnforderungID(rs.getLong("AnforderungID"));
				   a.setTestlaufID(rs.getLong("TestlaufID"));
				   
				   //System.out.println(current );
				   aList.add(a);
				}
				// Clean-up environment
				rs.close();
					

				
				stmt.close();
				conn.close();
				return aList;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Lesen in Tabelle Testfall !");
				return aList;
			} finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long insertTestfall(Testfall testfall){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Verbinden mit Datenbank
				System.out.println("insertTestfall): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);
				
				sql = "INSERT INTO Datenbank.Testfall"
						+ "(Beschreibung) VALUES"
						+ "(?)";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

				preparedStatement.setString(1, testfall.getBeschreibung());

				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		        }

		        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
		            if (generatedKeys.next()) {
		            	idNewRow = generatedKeys.getLong(1);
		            	System.out.println("ID des neuen Objektes: " + idNewRow);
		            }
		            else {
		                throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		            }
		        }			
					
				preparedStatement.close();
				conn.close();
				return idNewRow;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Anlegen der Zeile in Testfall !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long insertTestfallAnforderung(Testfall testfall, Anforderung anforderung){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Verbinden mit Datenbank
				System.out.println("insertTestfall): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);
				
				sql = "INSERT INTO Datenbank.Testfall"
						+ "(Beschreibung, AnforderungID, TestlaufID) VALUES"
						+ "(?,?,?)";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

				preparedStatement.setString(1, testfall.getBeschreibung());
				preparedStatement.setLong(2, anforderung.getId());
				preparedStatement.setLong(3, testfall.getTestlaufID());

				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		        }

		        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
		            if (generatedKeys.next()) {
		            	idNewRow = generatedKeys.getLong(1);
		            	System.out.println("ID des neuen Objektes: " + idNewRow);
		            }
		            else {
		                throw new SQLException("Creating row failed, no ID obtained.");
		            }
		        }			
					
				preparedStatement.close();
				conn.close();
				return idNewRow;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Anlegen der Zeile in Testfall !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long deleteTestfall(Testfall testfall){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Register JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				System.out.println("deleteTestfall(): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				sql = "DELETE FROM Datenbank.Testfall " +
					   "WHERE TestfallID = ?";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql);

				preparedStatement.setLong(1, testfall.getId());
				
				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Fehler beim Löschen. Zeile wurde nicht gefunden.");
		        } else {
		        	System.out.println("Objekt gelöscht!");
		        }

		       		
					
				preparedStatement.close();
				conn.close();
				return affectedRows;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Löschen aus Testfall !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		// Read from Database
		public List<Testergebnis> readTestergebnis(){
			List<Testergebnis> aList = new ArrayList<Testergebnis>();
			Connection conn = null;
			Statement stmt = null;
			String sql;
			String result;
			
			// Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				// System.out.println("Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				// System.out.println("SQL-Statement erstellen...");
				stmt = conn.createStatement();
				
				sql = "SELECT * FROM Datenbank.Testergebnis";
				ResultSet rs = stmt.executeQuery(sql);

				// Extract data from result set
				while(rs.next()){
					Testergebnis a = new Testergebnis();
				   //Retrieve by column name
				   a.setId(rs.getInt("TestergebnisID"));
				   a.setBeschreibung(rs.getString("Beschreibung"));
				   a.setTestfallID(rs.getLong("TestfallID"));
				   a.setTesterID(rs.getLong("TesterID"));
				   
				   //System.out.println(current );
				   aList.add(a);
				}
				// Clean-up environment
				rs.close();				
				stmt.close();
				conn.close();
				return aList;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Lesen in Tabelle Testergebnis !");
				return aList;
			} finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long insertTestergebnis(Testergebnis testergebnis, Testfall testfall){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				System.out.println("insertTestergebnis): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);
				
				sql = "INSERT INTO Datenbank.Testergebnis"
						+ "(Beschreibung, TestfallID, TesterID) VALUES"
						+ "(?,?,?)";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

				preparedStatement.setString(1, testergebnis.getBeschreibung());
				preparedStatement.setLong(2, testfall.getId());
				preparedStatement.setLong(3, testergebnis.getTesterID());

				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Einfügen fehlgeschlagen. Bitte die Eingaben auf Vollständigkeit prüfen.");
		        }

		        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
		            if (generatedKeys.next()) {
		            	idNewRow = generatedKeys.getLong(1);
		            	System.out.println("ID des neuen Objektes: " + idNewRow);
		            }
		            else {
		                throw new SQLException("Creating row failed, no ID obtained.");
		            }
		        }			
					
				preparedStatement.close();
				conn.close();
				return idNewRow;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Anlegen der Zeile in Testergebnis !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		public long deleteTestergebnis(Testergebnis testergebnis){
			Connection conn = null;
			PreparedStatement preparedStatement = null;
			String sql;
			
		     // Register JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				System.out.println("deleteTestergebnis(): Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				sql = "DELETE FROM Datenbank.Testergebnis " +
					   "WHERE TestergebnisID = ?";
				
				 // Create a prepared statement
				System.out.println("SQL-Statement erstellen...");
				preparedStatement = conn.prepareStatement(sql);

				preparedStatement.setLong(1, testergebnis.getId());
				
				// execute insert SQL statement
				Integer affectedRows = preparedStatement.executeUpdate();		
			
				Long idNewRow;
		        if (affectedRows == 0) {
		            throw new SQLException("Fehler beim Löschen. Zeile wurde nicht gefunden.");
		        } else {
		        	System.out.println("Objekt gelöscht!");
		        }

		       		
					
				preparedStatement.close();
				conn.close();
				return affectedRows;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Löschen aus Testergebnis !");
				return 0;
			} finally{
		      //finally block used to close resources
		      try{
		         if(preparedStatement!=null)
		        	 preparedStatement.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		// Read from Database
		public List<Benutzer> readTester(){
			List<Benutzer> aList = new ArrayList<Benutzer>();
			Connection conn = null;
			Statement stmt = null;
			String sql;
			String result;
			
			// Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				// System.out.println("Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				// System.out.println("SQL-Statement erstellen...");
				stmt = conn.createStatement();
				
				sql = "SELECT * FROM Datenbank.Benutzer WHERE Rolle = 'Tester'";
				ResultSet rs = stmt.executeQuery(sql);

				// Extract data from result set
				while(rs.next()){
					Benutzer a = new Benutzer();
				   //Retrieve by column name
				   a.setId(rs.getInt("BenutzerID"));
				   a.setName(rs.getString("Name"));
				   
				   aList.add(a);
				}
				// Clean-up environment
				rs.close();
					

				
				stmt.close();
				conn.close();
				return aList;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Lesen in Tabelle Benutzer !");
				return aList;
			} finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}
		
		// Read from Database
		public List<BenutzerTestlauf> readBenutzerTestlauf(){
			List<BenutzerTestlauf> aList = new ArrayList<BenutzerTestlauf>();
			Connection conn = null;
			Statement stmt = null;
			String sql;
			String result;
			
			// Adding JDBC driver
		      try {
				Class.forName(Driver);

				// Open a connection
				// System.out.println("Verbinden mit Datenbank...");
				conn = (Connection) DriverManager.getConnection(url, user, password);//getConnection(DB_URL,USER,PASS);
				
				// System.out.println("SQL-Statement erstellen...");
				stmt = conn.createStatement();
				
				sql = "SELECT * FROM Datenbank.Testlauf INNER JOIN Benutzer on Testlauf.TesterID = Benutzer.BenutzerID";
				ResultSet rs = stmt.executeQuery(sql);

				// Extract data from result set
				while(rs.next()){
					BenutzerTestlauf a = new BenutzerTestlauf();
				   //Retrieve by column name
				   a.setTestlaufId(rs.getInt("TestlaufID"));
				   a.setBeschreibung(rs.getString("Beschreibung"));
				   a.setBenutzerId(rs.getLong("BenutzerID"));
				   a.setTester(rs.getString("Name"));
				   
				   aList.add(a);
				}
				// Clean-up environment
				rs.close();
					

				
				stmt.close();
				conn.close();
				return aList;
				
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Fehler beim Lesen in Tabelle Testlauf und Benutzer!");
				return aList;
			} finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      } catch(SQLException se2){
		      }
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try	      
			
		}	
		
		
		
				
}
