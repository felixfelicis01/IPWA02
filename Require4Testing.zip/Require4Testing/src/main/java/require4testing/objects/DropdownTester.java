package require4testing.objects;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import require4testing.model.BenutzerTestlauf;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name="dropdownTester")
@ViewScoped
public class DropdownTester {
    private long selectedItem;
    private BenutzerTestlauf bt = new BenutzerTestlauf();
    private List<Long> itemList;

    @PostConstruct
    public void init() {
        itemList = new ArrayList<Long>();

        try {
            // Establish a database connection
            Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/Datenbank", "app", "Start2023!");

            // Execute a query to retrieve data
            String query = "SELECT BenutzerID FROM Benutzer WHERE Rolle='Tester'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the item list with the retrieved data
            while (resultSet.next()) {
                itemList.add(resultSet.getLong("BenutzerID"));
            }

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Getter and setter for selectedItem

    public long getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Long selectedItem) {
        this.selectedItem = selectedItem;
    }

    // Getter for itemList

    public List<Long> getItemList() {
        return itemList;
    }
    /*
    public void updateTable(long selectedItem, long testlaufId) {
        try {
            // Establish a database connection
            Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/Datenbank", "app", "Start2023!");

            // Execute an update query
            String query = "UPDATE Datenbank.Testlauf SET TesterID = ? WHERE TestlaufID = ?";            
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, selectedItem);
            preparedStatement.setLong(2, testlaufId);
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();

            // Close the resources
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    */
}
