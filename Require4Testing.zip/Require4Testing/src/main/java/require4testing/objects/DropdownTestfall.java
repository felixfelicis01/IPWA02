package require4testing.objects;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name="dropdownTestfall")
@ViewScoped
public class DropdownTestfall 
{
    private List<String> selectedValues;
    private List<String> availableValues;

    @PostConstruct
    public void init() {
        selectedValues = new ArrayList<>();
        availableValues = new ArrayList<>();
        
        // Populate available values from database
        try {
            Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/Datenbank", "app", "Start2023!");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT TestfallID FROM Datenbank.Testfall");

            while (resultSet.next()) {
                availableValues.add(resultSet.getString("TestfallID"));
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Getter and setter for selectedValues
    
    public List<String> getSelectedValues() {
        return selectedValues;
    }

    public void setSelectedValues(List<String> selectedValues) {
        this.selectedValues = selectedValues;
    }

    // Getter for availableValues
    
    public List<String> getAvailableValues() {
        return availableValues;
    }

    // Method to save selected values to the database
    
    public void saveSelectedValues() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "username", "password");
            
            // Clear existing values in the table
            Statement clearStatement = connection.createStatement();
            clearStatement.executeUpdate("DELETE FROM selected_values");
            clearStatement.close();
            
            // Insert selected values into the table
            PreparedStatement insertStatement = connection.prepareStatement("INSERT INTO selected_values (value) VALUES (?)");
            for (String value : selectedValues) {
                insertStatement.setString(1, value);
                insertStatement.executeUpdate();
            }
            insertStatement.close();
            
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
