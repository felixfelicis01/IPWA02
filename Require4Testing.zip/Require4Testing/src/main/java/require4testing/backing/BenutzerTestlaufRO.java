package require4testing.backing;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import require4testing.model.BenutzerTestlauf;
import require4testing.objects.DataController;

@ManagedBean(name="btRO")
@SessionScoped
public class BenutzerTestlaufRO 
{
	private BenutzerTestlauf bt = new BenutzerTestlauf();
	DataController controller = new DataController();
	public BenutzerTestlauf getBt() {
		return bt;
	}
	public void setBt(BenutzerTestlauf bt) {
		this.bt = bt;
	}
	public DataController getController() {
		return controller;
	}
	public void setController(DataController controller) {
		this.controller = controller;
	}
	@Override
	public String toString() {
		return "BenutzerTestlaufRO [bt=" + bt + ", controller=" + controller + "]";
	}
	public List<BenutzerTestlauf> readBenutzerTestlauf()
	{
		return controller.readBenutzerTestlauf();
	}
}
