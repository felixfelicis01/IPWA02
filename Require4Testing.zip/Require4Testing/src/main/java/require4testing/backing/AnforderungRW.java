package require4testing.backing;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import require4testing.model.Anforderung;
import require4testing.objects.DataController;

@ManagedBean(name="anforderungRW")
@SessionScoped
public class AnforderungRW
{
	private Anforderung anforderung = new Anforderung();
	private DataController controller = new DataController();	
	
	
	public Anforderung getAnforderung() 
	{
		return anforderung;
	}

	public void setAnforderung(Anforderung anforderung) 
	{
		this.anforderung = anforderung;
	}	
	
	 public List<Anforderung>readAnforderungen()
	 {
		 return controller.readAnforderungen();
	 }
		
	 public String speichern()
	{
		// Saving of issued info to database via the DataController
		controller.insertAnforderung(anforderung);
		// Returning to overview.xhtml after saving
		return "overview";
	}
	
	public void delete(Anforderung anforderung)
	{
		controller.deleteAnforderung(anforderung);
	}
}
