package require4testing.backing;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import require4testing.model.Anforderung;
import require4testing.model.Testfall;
import require4testing.objects.DataController;

@ManagedBean(name="testfallRW")
@SessionScoped
public class TestfallRW
{
	private Testfall testfall= new Testfall();
	private DataController controller = new DataController();		
	
	 public Testfall getTestfall() {
		return testfall;
	}

	public void setTestfall(Testfall testfall) {
		this.testfall = testfall;
	}

	public List<Testfall>readTestfall()
	 {
		 return controller.readTestfall();
	 }
		/*
	 public String speichern()
	{
		// Saving of issued info to database via the DataController
		controller.insertTestfall(testfall);
		// Returning to overview.xhtml after saving
		return "overview";
	}
	 */
	 public String speichernMitAnforderung(Anforderung anforderung)
	{
		// Saving of issued info to database via the DataController
		controller.insertTestfallAnforderung(testfall, anforderung);
		// Returning to overview.xhtml after saving
		return "overview";
	}
	
	public void delete(Testfall testfall)
	{
		controller.deleteTestfall(testfall);
	}
}
