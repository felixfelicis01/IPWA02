package require4testing.backing;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import require4testing.model.Testlauf;
import require4testing.objects.DataController;

@ManagedBean(name="testlaufRW")
@SessionScoped
public class TestlaufRW
{
	private Testlauf testlauf = new Testlauf();
	DataController controller = new DataController();	
	
	public Testlauf getTestlauf() 
	{
		return testlauf;
	}


	public void setTestlauf(Testlauf testlauf) 
	{
		this.testlauf = testlauf;
	}


	public DataController getController() 
	{
		return controller;
	}


	public void setController(DataController controller) 
	{
		this.controller = controller;
	}


	public List<Testlauf>readTestlauf()
	 {
		 return controller.readTestlauf();
	 }
	public String speichern()
	{
		// Saving of issued info to database via the DataController
		controller.insertTestlauf(testlauf);
		
		// Returning to overview.xhtml after saving
		return "overview";
	}
	
	public void delete(Testlauf testlauf)
	{
		// Saving of issued info to database via the DataController
		controller.deleteTestlauf(testlauf);
	}
}