package require4testing.backing;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

import require4testing.model.Benutzer;
import require4testing.objects.DataController;

@ManagedBean(name="benutzerRO")
@SessionScoped

public class BenutzerRO
{
	private Benutzer benutzer = new Benutzer();
	private List<Benutzer> tester;
	DataController controller = new DataController();
	
	@PostConstruct
	public void init() 
	{
	    tester = controller.readTester();
	}
	
	public Benutzer getBenutzer() 
	{
		return benutzer;
	}
	public void setBenutzer(Benutzer benutzer) 
	{
		this.benutzer = benutzer;
	}
	public DataController getController() 
	{
		return controller;
	}
	public void setController(DataController controller) 
	{
		this.controller = controller;
	}
	public List<Benutzer> getTester() {
		return tester;
	}

	public void setTester(List<Benutzer> tester) {
		this.tester = tester;
	}	
	@Override
	public String toString() {
		return "BenutzerRW [benutzer=" + benutzer + ", tester=" + tester + ", controller=" + controller + "]";
	}

	public List<Benutzer> readTester()
	{
		return controller.readTester();
	}
}
