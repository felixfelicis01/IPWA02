package require4testing.backing;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import require4testing.model.Benutzer;
import require4testing.model.Testergebnis;
import require4testing.model.Testfall;
import require4testing.objects.DataController;

@ManagedBean(name="testergebnisRW")
@SessionScoped
public class TestergebnisRW
{
	private Testergebnis testergebnis = new Testergebnis();
	private DataController controller = new DataController();		
	
	 public Testergebnis getTestergebnis() 
	 {
		return testergebnis;
	}

	public void setTestfall(Testergebnis testergebnis) 
	{
		this.testergebnis = testergebnis;
	}

	public List<Testergebnis>readTestergebnis()
	 {
		 return controller.readTestergebnis();
	 }
		
	 public String speichern(Testfall testfall)
	{
		// Saving of issued info to database via the DataController
		controller.insertTestergebnis(testergebnis, testfall);
		// Returning to overview.xhtml after saving
		return "overview";
	}
	
	public void delete(Testergebnis testergebnis)
	{
		controller.deleteTestergebnis(testergebnis);
	}
}
